import csv
import time
import geocoder
from bs4 import BeautifulSoup

from urllib import request
from urllib.parse import urlparse


def download_html(url):
    req = request.Request(url)
    entidad = urlparse(url).path.replace("/", "").replace("\n", "")
    print("Processing: {0}".format(entidad))
    with request.urlopen(req) as response:
        html_response = response.read()
        beautiful_soup = BeautifulSoup(html_response, "html.parser")
        trs = beautiful_soup.find("table", {"class": "oficialias"}).find("tbody").find_all("tr")

        with open("csvs/" + entidad + ".csv", "w") as csv_file:
            writer = csv.writer(csv_file, delimiter=',', quoting=csv.QUOTE_ALL)
            for tr in trs:
                tds = tr.find_all("td")
                nombre = tds[0].find("a").text.replace("\"", "")
                ubicacion = tds[1].text.replace("\"", "")
                telefono = tds[2].text.replace("\"", "")
                latitud_longitud = geocoder.google(ubicacion + " " + entidad.replace("-", " ")).latlng
                print(latitud_longitud)
                if latitud_longitud is None or len(latitud_longitud) == 0:
                    writer.writerow(
                        [entidad.replace("-", " "), nombre, ubicacion, None, None, telefono])
                else:
                    writer.writerow(
                        [entidad.replace("-", " "), nombre, ubicacion, latitud_longitud[0], latitud_longitud[1],
                         telefono])


def main():
    f_urls = open("urls.txt", "r")
    for line in f_urls:
        download_html(line)


start = time.time()
main()
end = time.time()
print("Tiempo de ejecución: %.2f segundos" % (end - start))
